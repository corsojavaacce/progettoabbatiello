package it.rdev.contacts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.rdev.contacts.dao.entity.Appuntamento;
import it.rdev.contacts.dao.repository.AppuntamentoRepository;

@Service
public class AppuntamentoService {

	
	@Autowired
	AppuntamentoRepository appuntamentoRepository;
	public List<Appuntamento> get(){
		return appuntamentoRepository.findAll();
	}
	public Appuntamento saveorupdate(Appuntamento appuntamento) {
		return appuntamentoRepository.saveAndFlush(appuntamento);
	}
	public void delete(Appuntamento appointment) {
		appuntamentoRepository.delete(appointment);
	};
}
