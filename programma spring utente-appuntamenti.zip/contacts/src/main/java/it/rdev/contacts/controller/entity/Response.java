package it.rdev.contacts.controller.entity;

import java.util.List;

public class Response<T> {
	
	private int totalRecords;
	private int records;
	private String message;
	private List<T> payload;
	
	public Response(List<T> payload, String message, int records, int totalRecords) {
		this.payload = payload;
		this.message = message;
		this.records = records;
		this.totalRecords = totalRecords;
	}

	public int getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	public int getRecords() {
		return records;
	}

	public void setRecords(int records) {
		this.records = records;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<T> getPayload() {
		return payload;
	}

	public void setPayload(List<T> payload) {
		this.payload = payload;
	}

}
