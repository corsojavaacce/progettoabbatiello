/*package it.rdev.contacts.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import it.rdev.contacts.dao.entity.Contact;
import it.rdev.contacts.dto.ContactDto;
import it.rdev.contacts.service.ContactService;

@RestController
@RequestMapping(value="/api/users")
public class UserController {
	
	@Autowired
	private ContactService contactService;
	
	@RequestMapping(
			method=RequestMethod.GET, 
	        produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Contact>> read( @RequestParam(name = "nome", required = false) String name ) {
		List<Contact> contacts = null;
		if( name != null ) {
			contacts = contactService.get( name );
		} else {
			contacts = contactService.getAll();
		}
		return new ResponseEntity<List<Contact>> ( contacts, HttpStatus.OK );
	}
	
	@RequestMapping(
			method=RequestMethod.POST,
			produces = MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Contact> create(@RequestBody Contact contact) {
		return new ResponseEntity<Contact> ( contactService.saveOrUpdate(contact), HttpStatus.OK );
	}
	
	@RequestMapping(
			value = "/{id}",
			method = { RequestMethod.PUT, RequestMethod.PATCH },
			produces = MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Contact> update(@PathVariable("id") int id, @RequestBody Contact contact) {
		return new ResponseEntity<Contact> ( contactService.saveOrUpdate(contact), HttpStatus.OK );
	}
	
	@RequestMapping(
			value = "/{id}",
			method=RequestMethod.DELETE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> delete(@PathVariable("id") int id) {
		contactService.delete(id);
		return new ResponseEntity<String> ( "{ \"status\" : \"OK\"} ", HttpStatus.OK );
	}

}*/
