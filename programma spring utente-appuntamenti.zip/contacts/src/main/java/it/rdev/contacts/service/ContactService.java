/*package it.rdev.contacts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.rdev.contacts.dao.converter.IConverter;
import it.rdev.contacts.dao.entity.Contact;
import it.rdev.contacts.dao.repository.ContactRepository;
import it.rdev.contacts.dto.ContactDto;

@Service
public class ContactService {
	
	@Autowired
	private ContactRepository dao;
	
	@Autowired
	private IConverter dataConverter;
	
	public List<Contact> getAll() {
		return dataConverter.convertEntitiesToDtos(dao.findAll(), Contact.class);
	}
	
	public List<Contact> get(String nome) {
		return dataConverter.convertEntitiesToDtos(dao.findUserByName(nome), Contact.class);
	}
	
	public Contact saveOrUpdate(Contact contact) {
		return dataConverter.convertEntityToDto(
				dao.save( dataConverter.convertDtoToEntity(contact, Contact.class) ),
				Contact.class);
	}
	
	public void delete( int id ) {
		dao.deleteById(id);
	}

}
*/