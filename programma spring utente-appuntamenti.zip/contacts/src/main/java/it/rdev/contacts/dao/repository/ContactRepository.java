/*package it.rdev.contacts.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import it.rdev.contacts.dao.entity.Contact;

public interface ContactRepository extends JpaRepository<Contact, Integer>{
	
	@Query("SELECT c FROM Contact c WHERE c.nome = ?1")
	List<Contact> findUserByName(String name);

}
*/