package it.rdev.contacts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.rdev.contacts.dao.entity.Utente;
import it.rdev.contacts.dao.repository.UtenteRepository;

@Service
public class UtenteService {
	
	
	@Autowired
	UtenteRepository utenteRepository;
	public List<Utente> get(){
		return utenteRepository.findAll();
	}
	public List<Utente> getById(Integer id){
		return utenteRepository.getByID(id);
	}
	public Utente saveorupdate(Utente utente) {
		return utenteRepository.saveAndFlush(utente);
	}
	public void delete(Utente utente) {
		utenteRepository.delete(utente);
	}

}
