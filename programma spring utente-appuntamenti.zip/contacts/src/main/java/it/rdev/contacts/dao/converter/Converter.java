/*package it.rdev.contacts.dao.converter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import it.rdev.contacts.dao.entity.AbstractEntity;
import it.rdev.contacts.dao.entity.Contact;
import it.rdev.contacts.dto.ContactDto;
import it.rdev.contacts.dto.IDto;

/**
 * 
 * @author danilo di nuzzo
 *
 
@Service
public class Converter implements IConverter {
	
	private static final Logger log = LoggerFactory.getLogger(Converter.class);
	
	private static Map<Class<? extends AbstractEntity>, Class<? extends IDto>> entityToDto = new HashMap<>();
	static {
		entityToDto.put(Contact.class, ContactDto.class);
	}

	public <T, E> T convert(E from, Class<T> to) {
		T dto = null;
		try {
			// Provo a creare una nuova istanza dell'oggetto da restituire
			dto = to.newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		if( dto != null ) {
			// Recupero i metodi dell'oggetto da cui prelevare le informazioni
			Method[] entityMethods = from.getClass().getMethods();
			for(Method entityMethod:entityMethods) {
				String entityMethodName = entityMethod.getName();
				// Se il metodo inizia con "get"
				if( entityMethodName.startsWith("get") ) {
					Method[] dtoMethods = dto.getClass().getMethods();
					String dtoMethodName = entityMethodName.replaceFirst("get", "set");
					LOOP_METHODS:
					for(Method dtoMethod:dtoMethods) {
						if( dtoMethod.getName().equalsIgnoreCase(dtoMethodName) ) {
							try {
								// Recupero il valore da passare al set
								Object objToSet = entityMethod.invoke(from);
								if(objToSet != null ) {
									// Verifico se si tratta di una classe DTO o Entity
									Set<Class<? extends AbstractEntity>> keys = entityToDto.keySet();
									LOOP_INTERNAL_OBJECTS:
									for(Class<? extends AbstractEntity> entityClass:keys) {
										Class<? extends IDto> dtoClass = entityToDto.get(entityClass);
										if( objToSet.getClass().getName().contains(entityClass.getName()) ) {
											objToSet = convert(objToSet, dtoClass);
											break LOOP_INTERNAL_OBJECTS;
										}
										if( objToSet.getClass().getName().contains(dtoClass.getName()) ) {
											objToSet = convert(objToSet, entityClass);
											break LOOP_INTERNAL_OBJECTS;
										}
									}
								}
								dtoMethod.invoke(dto, objToSet);
								break LOOP_METHODS;
							} catch (IllegalAccessException e) {
								log.error("Errore nel metodo [convert] del converter generico durante la parserizzazione del metodo [" + dtoMethod + "] della classe [" + dto.getClass().getSimpleName() + "]", e);
							} catch (IllegalArgumentException e) {
								log.error("Errore nel metodo [convert] del converter generico durante la parserizzazione del metodo [" + dtoMethod + "] della classe [" + dto.getClass().getSimpleName() + "]", e);
							} catch (InvocationTargetException e) {
								log.error("Errore nel metodo [convert] del converter generico durante la parserizzazione del metodo [" + dtoMethod + "] della classe [" + dto.getClass().getSimpleName() + "]", e);
							}
						}
					}
				}
			}
		}
		return dto;
	}

	@Override
	public <T, E> E convertDtoToEntity(T dto, Class<E> entityClass) {
		return convert(dto, entityClass);
	}

	@Override
	public <T, E> T convertEntityToDto(E entity, Class<T> dtoClass) {
		return convert(entity, dtoClass);
	}

	@Override
	public <T, E> List<T> convertEntitiesToDtos(List<E> entities, Class<T> dtoClass) {
		List<T> list = new ArrayList<T>();
		for(E entity:entities) {
			T dto = convert(entity, dtoClass);
			list.add(dto);
		}
		return list;
	}

	@Override
	public <T, E> List<E> convertDtosToEntities(List<T> dtos, Class<E> entityClass) {
		List<E> list = new ArrayList<E>();
		for(T dto:dtos) {
			E entity = convert(dto, entityClass);
			list.add(entity);
		}
		return list;
	}

}*/