package it.rdev.contacts.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import it.rdev.contacts.dao.entity.Utente;

public interface UtenteRepository extends JpaRepository<Utente, Integer> {
@Query("FROM Utente u WHERE u.id=?1")
List<Utente> getByID(Integer id);
}
