package it.rdev.contacts.dto;

public interface IDto {

}
