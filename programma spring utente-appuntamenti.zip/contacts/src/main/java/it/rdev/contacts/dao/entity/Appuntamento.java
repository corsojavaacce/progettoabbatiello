package it.rdev.contacts.dao.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "appuntamento", schema = "public")
public class Appuntamento {

	@Id
	@SequenceGenerator(name = "seq_appuntamento", schema = "public", sequenceName="appuntamento_idappuntamento_seq", allocationSize=1, initialValue=1)
	@GeneratedValue(strategy= GenerationType.SEQUENCE,generator = "seq_appuntamento")
	@Column(name="idappuntamento")
	private Integer idappuntamento;
	@Column(name="descrizione")
	private String descrizione;
	@Column(name="luogo")
	private String luogo;
	@Column(name="data")
	private String data;

		@ManyToOne
		@JoinColumn(name="id")
		private Utente U;
		
	
public Integer getIdappuntamento() {
			return idappuntamento;
		}

		public void setIdappuntamento(Integer idappuntamento) {
			this.idappuntamento = idappuntamento;
		}

public Utente getU() {
		return U;
	}

	public void setU(Utente u) {
		U = u;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getLuogo() {
		return luogo;
	}

	public void setLuogo(String luogo) {
		this.luogo = luogo;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}



}
