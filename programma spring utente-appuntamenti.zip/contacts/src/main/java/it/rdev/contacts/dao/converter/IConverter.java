package it.rdev.contacts.dao.converter;

import java.util.List;

public interface IConverter {
	public <T, E> T convertEntityToDto( E entity, Class<T> dtoClass );
	public <T, E> E convertDtoToEntity( T dto, Class<E> entityClass );
	public <T, E> List<T> convertEntitiesToDtos( List<E> entities, Class<T> dtoClass );
	public <T, E> List<E> convertDtosToEntities( List<T> dtos, Class<E> entityClass );
}
