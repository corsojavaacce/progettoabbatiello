package it.rdev.contacts.dao.entity;

import java.io.Serializable;

public abstract class AbstractEntity implements Serializable {

	private static final long serialVersionUID = 6138397322671338549L;

}
