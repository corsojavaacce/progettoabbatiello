package it.rdev.contacts.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import it.rdev.contacts.dao.entity.Appuntamento;
import it.rdev.contacts.service.AppuntamentoService;


@RestController
@RequestMapping(value = "/api/appuntamento")
public class AppuntamentoController {

	@Autowired
	AppuntamentoService service;
	
	@RequestMapping(method =RequestMethod.POST)
	public Appuntamento inserisciAppuntamento(@RequestBody Appuntamento appointment) {
		return service.saveorupdate(appointment);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public List<Appuntamento> getAllAppuntamento() {
		return service.get();
	}
	@RequestMapping(method=RequestMethod.DELETE)
	public void delete(@RequestBody Appuntamento appointment) {
		 service.delete(appointment);
	}
	
}
