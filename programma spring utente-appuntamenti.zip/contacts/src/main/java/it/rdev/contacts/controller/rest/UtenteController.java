package it.rdev.contacts.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import it.rdev.contacts.dao.entity.Utente;
import it.rdev.contacts.service.UtenteService;

@RestController
@RequestMapping(value="/api/utente")
public class UtenteController {
	
	@Autowired
	UtenteService service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Utente> getAllUtente(@RequestParam(name="id", required=false)Integer id){
		if(id==null) {
			return service.get();
		}else {
			return service.getById(id);
		}
		
	}
	@RequestMapping(method=RequestMethod.POST)
	public Utente inserisciUtente(@RequestBody Utente utente){
		return service.saveorupdate(utente);
	}
	@RequestMapping(method=RequestMethod.DELETE)

	public void delete(@RequestBody Utente utente) {
		service.delete(utente);
	}
}
