package it.rdev.contacts.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import it.rdev.contacts.dao.entity.Appuntamento;

public interface AppuntamentoRepository extends JpaRepository<Appuntamento, Integer> {

}
