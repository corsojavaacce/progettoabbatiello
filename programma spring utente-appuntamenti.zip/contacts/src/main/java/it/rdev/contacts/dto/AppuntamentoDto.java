package it.rdev.contacts.dto;

import java.sql.Date;

public class AppuntamentoDto {

	private int idappuntamento;
	private String descrizione;
	private String luogo;
	private String data;


	public AppuntamentoDto() {
		super();
	}

	
	public AppuntamentoDto(int idappuntamento, String descrizione, String luogo, String data) {
		super();
		this.idappuntamento = idappuntamento;
		this.descrizione = descrizione;
		this.luogo = luogo;
		this.data = data;
	}


	

	public int getIdappuntamento() {
		return idappuntamento;
	}

	public void setIdappuntamento(int idappuntamento) {
		this.idappuntamento = idappuntamento;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getLuogo() {
		return luogo;
	}

	public void setLuogo(String luogo) {
		this.luogo = luogo;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}